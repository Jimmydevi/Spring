package com.spring.core.chap01;

public interface Chef {
    void cook();
}
