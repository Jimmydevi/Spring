package com.spring.core.chap01;

public class ChineseChef implements Chef{
    @Override
    public void cook() {
        System.out.println("중식 경력 30년 김짜장 입니다.");
    }
}
