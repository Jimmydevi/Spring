package com.spring.core.chap01;

public class JapaneseChef implements Chef{
    @Override
    public void cook() {
        System.out.println("일식요리사 김수시 입니다.");
    }
}
