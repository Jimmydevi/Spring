package com.spring.core.chap01;

public interface Course {
    void combinedMenu(); //코스요리 구성
}
