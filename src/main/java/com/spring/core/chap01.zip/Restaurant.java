package com.spring.core.chap01;

public interface Restaurant {
    void order();

}

